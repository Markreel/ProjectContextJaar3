using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

namespace Klak.Timeline
{
    [System.Serializable]
    class AudioPreviewMixer : PlayableBehaviour
    {
    }
}
